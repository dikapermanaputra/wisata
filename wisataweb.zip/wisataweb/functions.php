<?php
	$dbhost = "localhost";
	$dbuser = "root";
	$pass = "";
	$db = "input_form";
	$conn = mysqli_connect($dbhost, $dbuser, $pass, $db ) or die ("gagal masuk database");

?>