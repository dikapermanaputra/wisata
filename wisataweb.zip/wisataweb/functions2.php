<?php 
//Input_tabel form
include"functions.php";
$ni = $_REQUEST['NoIdentitas'];
$user = $_REQUEST['Username'];
$nama = $_REQUEST['NamaLengkap'];
$pass = $_REQUEST['Password'];
$tgl = $_REQUEST['Tanggal'];
$jk = $_REQUEST['jk'];
$address = $_REQUEST['Alamat'];

$mysqli = "INSERT INTO input_tabel(No_Identitas, User_name, Nama_Lengkap, Password, Tanggal, Jenis_Kelamin, Alamat)
		   VALUES('$ni', '$user','$nama','$pass', '$tgl', '$jk', '$address')";
//kriteria wisata
$nama = $_REQUEST['nama_wisata'];
$jenis = $_REQUEST['jenis'];
$fasilitas = $_REQUEST['fasilitas'];
$ht = $_REQUEST['harga_tiket'];
$jp = $_REQUEST['jumlah_pengunjung'];
$jw = $_REQUEST['jarak_wisata'];

$wisatawan = "INSERT INTO kriteriawisata(nama_wisata, jenis, fasilitas, hargatiket, jumlah_pengunjung, jarak_wisata)
		   VALUES('$nama', '$jenis','$fasilitas','$ht', '$jp', '$jw')";


$result = mysqli_query($conn, $mysqli);

if ($result){
	echo "<script>
			alert('Berhasil Mengisi Data Buku Tamu !!! Silahkan Melanjutkan ke Pengisian Sistem Pendukung Keputusan Pemilihan Objek Wisata');
		 </script>";
}else{
	echo mysqli_error($conn);
}
mysqli_close($conn);
 ?>
 <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sistem Pendukung Keputusan</title>
</head>

<style type="text/css">
	p{
		font-size: 25px;
		margin-left: 50px;
	}
	td{
		padding-left: 395px;
	}
	td2{
		padding-left: 375px;
	}
	td3{
		padding-left: 297px;
	}
	td4{
		padding-left: 242px;
	}
	td5{
		padding-left: 225px;
	}
	input[type="reset"]{
	margin-bottom: 28px;
	width: 120px;
	height: 32px;
	background: #F44336;
	border: none;
	border-radius: 2px;
	color: #fff;
	font-family: sans-serif;
	text-transform: uppercase;
	transition: 0.2s ease;
	cursor: pointer;
	}
	input[type="submit"]{
	margin-bottom: 28px;
	width: 120px;
	height: 32px;
	background: #39f436;
	border: none;
	border-radius: 2px;
	color: #fff;
	font-family: sans-serif;
	text-transform: uppercase;
	transition: 0.2s ease;
	cursor: pointer;
	}
	font2{
		font-size: 17px;
		padding-left: 50px;
	}
	th{
		padding-left: 50px;
	}
</style>
<body>

	<p><br>Sistem Pendukung Keputusan<p>
	<font size="4">Pemilihan Objek Pariwisata Tegal</font>
	<p align="center"><b>Silahkan Masukkan Kriteria Objek Wisata</b></p>
	<form name="input" action="#" method="get">
	<table>
		<tr>
			<td><b>Jenis&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="Jenis" value="Alam"/>Alam
				<input type="radio" name="Jenis" value="Sosial & Budaya"/>Sosial & Budaya
				<input type="radio" name="Jenis" value="Sejarah & Religi"/>Sejarah & Religi
			</td>
		</tr>
	</table><br>
	<table>
		<tr>
			<td2><b>Fasilitas&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="fasilitas" value="Sedikit"/>Sedikit
				<input type="radio" name="fasilitas" value="Cukup"/>Cukup
				<input type="radio" name="fasilitas" value="Banyak"/>Banyak
			</td2>
		</tr>
	</table><br>
	<table>
	<tr>
			<td3><b>Harga Tiket Wisata&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="harga" value="Murah"/>Murah
				<input type="radio" name="harga" value="Sedang"/>Sedang
				<input type="radio" name="harga" value="Mahal"/>Mahal
			</td3>
		</tr>
	</table><br>
	<table>
	<tr>
			<td4><b>Jumlah Pengunjung Wisata&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="jumlah" value="Sepi"/>Sepi
				<input type="radio" name="jumlah" value="Sedang"/>Sedang
				<input type="radio" name="jumlah" value="Ramai"/>Ramai
			</td4>
		</tr>
	</table><br>
	<table>
	<tr>
			<td5><b>Jarak Wisata Dari Pusat Kota&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="jarak" value="Dekat"/>Dekat
				<input type="radio" name="jarak" value="Sedang"/>Sedang
				<input type="radio" name="jarak" value="Jauh"/>Jauh
			</td5>
		</tr>
	<tr>
			<td></td>
			<td><input type="submit" name="submit" value="Proses">
				<input type="reset" value="reset">
			</td>
	</tr>
	</table>
	<font2><b>Berikut adalah saran objek wisata yang akan di kunjungi sesuai dengan kriteria yang anda inputkan:</font2>
	<table style="width: 800px;" class="table table-bordered">
		<thead class="thead-dark">
		<tr>
			<th>No&nbsp;&nbsp;</th>
			<th>Nama Wisata&nbsp;&nbsp;</th>
			<th>Jenis&nbsp;&nbsp;</th>
			<th>Fasilitas&nbsp;&nbsp;</th>
			<th>Harga Tiket&nbsp;&nbsp;</th>
			<th>Jumlah Pengunjung&nbsp;&nbsp;</th>
			<th>Jarak Wisata&nbsp;&nbsp;</th>
		</tr>
		</thead>
	</table>
</body>
</html>