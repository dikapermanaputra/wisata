<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">

<body style="background-image:url(background.jpg)">
	<div id="login-box"><br>
		<td></td>
			<font size="5">&nbsp;&nbsp;&nbsp;Sistem Pendukung Keputusan Pariwisata</font><br>
		<text><br>&nbsp;&nbsp;&nbsp;&nbsp;Silahkan mengisi data buku tamu bagi calon wisatawan untuk dapat<br>&nbsp;&nbsp;&nbsp;&nbsp;mengakses Sistem pendukung keputusan Pemilihan Objek Pariwisata Tegal<text>
	<form method="post" action="functions2.php">
	<table>
		<tr>
			<td height="50px">&nbsp;&nbsp;&nbsp;&nbsp;No Identitas</td>
			<td><input type="text" name="NoIdentitas" placeholder="No Identitas"></td>
		</tr>
		<tr>
			<td height="50px">&nbsp;&nbsp;&nbsp;&nbsp;Nama Lengkap</td>
			<td><input type="text" name="NamaLengkap" placeholder="Nama Lengkap"></td>
		</tr>
		<tr>
			<td height="50px">&nbsp;&nbsp;&nbsp;&nbsp;Username</td>
			<td><input type="text" name="Username" placeholder="Username"></td>
		</tr>
		<tr>
			<td height="50px">&nbsp;&nbsp;&nbsp;&nbsp;Password</td>
			<td><input type="password" name="Password" placeholder="Password"></td>
		</tr>
		<tr>
			<td height="50px">&nbsp;&nbsp;&nbsp;&nbsp;Tanggal Lahir</td>
			<td><input type="date" name="Tanggal" placeholder="Tanggal Lahir"></td>
		</tr>
		<tr>
			<td height="50px">&nbsp;&nbsp;&nbsp;&nbsp;Jenis Kelamin</td>
			<td><input type="radio" name="jk" value="Laki-laki"/>Laki-laki
				<input type="radio" name="jk" value="Perempuan"/>Perempuan
			</td>
		</tr>
			<tr>
			<td height="50px">&nbsp;&nbsp;&nbsp;&nbsp;Alamat</td>
			<td><textarea type="address" name="Alamat"></textarea>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="submit" value="Tambah Data">
				<input type="reset" value="Reset">
				<input type="button" value="Batal">
			</td>
		</tr>
	</div>

	<div class="right-box"></div>
</table>
</form>
</head>
<body>
</form>