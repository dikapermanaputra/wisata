<form method="post" action="functions2.php">
	<table>
		<tr>
			<td><b>Jenis&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="Jenis" value="Alam"/>Alam
				<input type="radio" name="Jenis" value="Sosial & Budaya"/>Sosial & Budaya
				<input type="radio" name="Jenis" value="Sejarah & Religi"/>Sejarah & Religi
			</td>
		</tr>
	</table><br>
	<table>
		<tr>
			<td2><b>Fasilitas&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="fasilitas" value="Sedikit"/>Sedikit
				<input type="radio" name="fasilitas" value="Cukup"/>Cukup
				<input type="radio" name="fasilitas" value="Banyak"/>Banyak
			</td2>
		</tr>
	</table><br>
	<table>
	<tr>
			<td3><b>Harga Tiket Wisata&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="harga" value="Murah"/>Murah
				<input type="radio" name="harga" value="Sedang"/>Sedang
				<input type="radio" name="harga" value="Mahal"/>Mahal
			</td3>
		</tr>
	</table><br>
	<table>
	<tr>
			<td4><b>Jumlah Pengunjung Wisata&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="jumlah" value="Sepi"/>Sepi
				<input type="radio" name="jumlah" value="Sedang"/>Sedang
				<input type="radio" name="jumlah" value="Ramai"/>Ramai
			</td4>
		</tr>
	</table><br>
	<table>
	<tr>
			<td5><b>Jarak Wisata Dari Pusat Kota&nbsp;&nbsp;&nbsp;</b>
				<input type="radio" name="jarak" value="Dekat"/>Dekat
				<input type="radio" name="jarak" value="Sedang"/>Sedang
				<input type="radio" name="jarak" value="Jauh"/>Jauh
			</td5>
		</tr>
	<tr>
			<td></td>
			<td><input type="submit" name="submit" value="Proses">
				<input type="reset" value="reset">
			</td>
	</tr>
	</table>
	</div>